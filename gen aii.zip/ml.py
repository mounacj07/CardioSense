import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report

# 🔹 Load dataset (use heart dataset CSV)
df = pd.read_csv("heart_disease_uci.csv")
df = df.replace('?', pd.NA)
df = df.fillna(df.median(numeric_only=True))

# 🔹 Select relevant features
X = df[['age', 'trestbps', 'chol', 'thalch']]  
y = df['num'].apply(lambda x: 1 if x > 0 else 0)  # 0 or 1

# Rename for clarity (optional)
X.columns = ['age', 'bp', 'cholesterol', 'heart_rate']

# 🔹 Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# 🔹 Scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 🔹 Model 1: Logistic Regression
lr = LogisticRegression()
lr.fit(X_train, y_train)

# 🔹 Model 2: Decision Tree
dt = DecisionTreeClassifier(max_depth=4)
dt.fit(X_train, y_train)

# 🔹 Evaluate
print("Logistic Regression Accuracy:", accuracy_score(y_test, lr.predict(X_test)))
print("Decision Tree Accuracy:", accuracy_score(y_test, dt.predict(X_test)))

print("\nClassification Report (DT):")
print(classification_report(y_test, dt.predict(X_test)))

# 🔹 FUNCTION to use in your GenAI pipeline
def predict_disease(user_data):
    input_df = pd.DataFrame([user_data])

    # scale input
    input_scaled = scaler.transform(input_df)

    # use best model (Decision Tree here)
    prediction = dt.predict(input_scaled)[0]

    return prediction